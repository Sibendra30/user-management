package com.nt.users.usermanagement.entity;

public class UsersDto {

  private Long id;
  private String name;
  private String department;
  private String managerName;

}
