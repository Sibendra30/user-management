package com.nt.users.usermanagement.service.impl;

import com.nt.users.usermanagement.model.User;
import com.nt.users.usermanagement.service.UsersService;

public class UsersServiceImpl implements UsersService {

  @Override
  public User createUser(User user) {
    return null;
  }
}
