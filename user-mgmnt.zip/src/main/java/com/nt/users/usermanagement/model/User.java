package com.nt.users.usermanagement.model;

public class User {

  private Long id;
  private String name;
  private String department;
  private String managerName;

}
