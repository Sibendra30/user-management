package com.nt.users.usermanagement.service.impl;

public class UsersRepository extends CrudRepo{

}
