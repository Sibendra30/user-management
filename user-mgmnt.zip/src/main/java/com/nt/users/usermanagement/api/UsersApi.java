package com.nt.users.usermanagement.api;

import com.nt.users.usermanagement.model.User;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/users")
public interface UsersApi {

  @PostMapping
  ResponseEntity<User> createUser(@RequestBody User user);

  @GetMapping
  ResponseEntity<List<User>> getUsers();

  @GetMapping("/{id}")
  ResponseEntity<User> getUserById(@PathVariable("id") Long id);

}
