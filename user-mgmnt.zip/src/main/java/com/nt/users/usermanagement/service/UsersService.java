package com.nt.users.usermanagement.service;

import com.nt.users.usermanagement.model.User;

public interface UsersService {

  public User createUser(User user);

}
