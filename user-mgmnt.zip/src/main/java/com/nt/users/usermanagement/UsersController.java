package com.nt.users.usermanagement;

import com.nt.users.usermanagement.api.UsersApi;
import com.nt.users.usermanagement.model.User;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class UsersController implements UsersApi {

  @Override
  public ResponseEntity<User> createUser(User user) {
    System.out.println("Creating user....");
    return null;
  }

  @Override
  public ResponseEntity<List<User>> getUsers() {
    System.out.println("Get all user....");
    return null;
  }

  @Override
  public ResponseEntity<User> getUserById(Long id) {
    System.out.println("Get user by Id....");
    return null;
  }
}
